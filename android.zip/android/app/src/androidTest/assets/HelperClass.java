package io.gonative.android;

public class HelperClass {
    public static int newLoad = 0;
}
